# Ballot Design Patterns

Designing fair ballots.
