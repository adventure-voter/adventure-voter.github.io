# Anti-patterns

What to avoid.
