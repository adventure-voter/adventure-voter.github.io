# Setup

How to wire it into your project.
